<?php 

session_start();
require 'koneksiHewan.php';

if (!isset($_SESSION["login"])) {
  header("Location: index.php");
  exit;
}

//$hewan = query("SELECT * FROM data_hewan");
$hewan = mysqli_query($conn,"SELECT * FROM data_hewan");
// $user = mysqli_query($conn,"SELECT * FROM users");
// $totalhewan = mysqli_num_rows($hewan);
// $totaluser = mysqli_num_rows($user);
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<!-- Required meta tags -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />
	<link rel="stylesheet" href="fontawesome-free/css/all.min.css" >


	<link rel="stylesheet" type="text/css" href="admin.css">

	<title>Admin Dashboard</title>
</head>
<body>

	<!-- Navbar -->

	<nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top">
		<div class="container-fluid">
			<a class="navbar-brand" href="#">Admin Dashboard | <b><?= $_SESSION["nama"];?></b></a>
			<form class="d-flex">
				<input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
				<button class="btn btn-outline-success" type="submit">Search</button>
			</form>
			<a class="navbar-brand" href="index.php"><i class="fas fa-sign-out-alt" bs-data-toggle="tooltip" title="Kembali ke Beranda"></i></a>   
		</div>
	</div>
</nav>

<!-- /Navbar -->


<div class="row no-gutters mt-5">
	<div class="col-md-2 mt-2 pr-3 pt-4" style="background-color:#1C4E80;">
		<ul class="nav flex-column ml-3 mb-5">
			<li class="nav-item">
				<a class="nav-link active text-white" aria-current="page" href="dashboard.php"><i class="fas fa-tachometer-alt mr-2"></i> Dashboard</a>  <hr class="bg-primary"> 
			</li>
			<li class="nav-item">
				<a class="nav-link text-white" href="dashboardhewan.php"><i class="fas fa-database mr-2"></i> Data Hewan</a><hr class="bg-primary">
			</li>
			<li class="nav-item">
				<a class="nav-link text-white" href="dashboarduser.php"><i class="fas fa-user mr-2"></i> Data User</a><hr class="bg-primary">
			</li>
			<li class="nav-item">
				<a class="nav-link text-white" href="#"><i class="fas fa-history mr-2"></i> Riwayat Transaksi</a><hr class="bg-primary">
			</li>
		</ul>
	</div>
	<div class="col-md-10 p-5 pt-2">
		<h3><i class="fas fa-database mr-2"></i> Daftar Hewan</h3><hr>
		<a href="tambahHewan.php" class="btn btn-success mb-3"   bs-data-toggle="tooltip" title="Tambah data"><i class="fas fa-plus mr-2"></i>Tambah data hewan</a>
		<table class="table" border="1" cellpadding="10" cellspacing="0">
			<thead class="thead-dark">
				<tr>
					<th scope="col">#</th>
					<th scope="col">Kode Hewan</th>
					<th scope="col">Gambar</th>
					<th scope="col">Nama Hewan</th>
					<th scope="col">Jenis Hewan</th>
					<th scope="col">Jenis Kelamin</th>
					<th scope="col">Berat (kg)</th>
					<th scope="col">Umur</th>
					<th scope="col">Harga</th>
					<th scope="col">Jumlah</th>
					<th scope="col">Aksi</th>
				</tr>
			</thead>
			<tbody>
				<?php $i = 1;  ?>
				<?php foreach ($hewan as $row) : ?>
					<tr>
						<th scope="row"> <?= $i ?></th>
						
									<td><?= $row["id_hewan"]; ?></td>
									<td><img src="img/<?= $row["gambar"];  ?>" class="rounded mx-auto d-block" width="100" alt=""> </td>
									<td><?= $row["nama_hewan"]; ?></td>
									<td><?= $row["jenis_hewan"]; ?></td>
									<td><?= $row["jenis_kelamin"]; ?></td>
									<td><?= number_format($row["berat_hewan"]); ?></td>
									<td><?= $row["umur_hewan"]; ?></td>
									<td><?= number_format($row["harga_hewan"]); ?></td>
									<td><?= $row["jumlah_hewan"]; ?></td>
									<?php
						if(!isset($_SESSION["login"])) :?>
							<td><a href="loginform.php" class="btn btn-success">Tambah ke keranjang</a></td>
							<?php elseif($_SESSION["role"]=="Admin") : ?>
								<td><a href="updateHewan.php?id_hewan=<?= $row["id_hewan"]; ?>" class="btn btn-primary" bs-data-toggle="tooltip" title="Ubah data"><i class="fas fa-edit"></i></a>
									<a href="hapusHewan.php?id_hewan=<?= $row["id_hewan"]; ?>" class="btn btn-danger "  bs-data-toggle="tooltip" title="Hapus data"  onclick="return confirm('Data mau dihapus?')"><i class="fas fa-trash-alt"></i></a>
									</td>
									<?php else : ?>
										<td><a href="" class="btn btn-success">Tambah ke keranjang</a></td>
									<?php endif; ?>
								</tr>
								<?php $i++; ?>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>

	</div>


	<!-- /Navbar -->

	<!-- Optional JavaScript; choose one of the two! -->

	<!-- Option 1: Bootstrap Bundle with Popper -->
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW" crossorigin="anonymous"></script>

	<!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>
-->
</body>
</html>