<?php 

session_start();
session_unset(); //untuk memastikan sessionnya hilang
session_destroy();
            
header("Location: index.php");
exit;

 ?>