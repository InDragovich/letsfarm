-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 13, 2020 at 05:39 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `letsfarm`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `nama`, `email`, `username`, `password`) VALUES
(1, 'Agus', 'qwerty@gmail.com', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `data_hewan`
--

CREATE TABLE `data_hewan` (
  `id_hewan` int(255) NOT NULL,
  `nama_hewan` varchar(255) NOT NULL,
  `jenis_hewan` varchar(255) NOT NULL,
  `jenis_kelamin` varchar(255) NOT NULL,
  `berat_hewan` int(255) NOT NULL,
  `umur_hewan` int(255) NOT NULL,
  `harga_hewan` int(255) NOT NULL,
  `jumlah_hewan` int(11) NOT NULL,
  `gambar` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `data_hewan`
--

INSERT INTO `data_hewan` (`id_hewan`, `nama_hewan`, `jenis_hewan`, `jenis_kelamin`, `berat_hewan`, `umur_hewan`, `harga_hewan`, `jumlah_hewan`, `gambar`) VALUES
(1, 'sapi', 'sapi ongole', 'jantan', 500, 20, 12000000, 5, '5fcf0dc73c99c.jpg'),
(7, 'Ayam', 'Ayam Mutiara', 'Betina', 5, 5, 123, 3, '5fcf10a3be6e4.jpg'),
(8, 'Kambing', 'Kambing Himalaya', 'Jantan', 5, 5, 213, 1233, '5fd3399444a69.jpeg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `nohp` varchar(64) NOT NULL,
  `jeniskelamin` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `nama`, `nohp`, `jeniskelamin`, `email`, `username`, `password`, `role`) VALUES
(1, 'David Disini', '0811', 'Laki - Laki', 'david@gmail.com', 'admin', 'admin', 'Admin'),
(8, 'Agus Indra', '+6282251622192', 'Laki - Laki', 'qwerty@gmail.com', 'qwe', '$2y$10$hgIvbUIw1LakZVhrbkaokOUKGYkzh1FCj4GybQTmMvLEjuzHrsUUK', 'User'),
(12, 'Sherlock Holmes', '+6282251622192', '', 'agusindra376@gmail.com', 'serlok', '$2y$10$VoQXco/5Aj0TSBsqMVoYr.tPwCEyxZZIsnsp8h3l5urj80x57JWjq', 'Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_hewan`
--
ALTER TABLE `data_hewan`
  ADD PRIMARY KEY (`id_hewan`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `data_hewan`
--
ALTER TABLE `data_hewan`
  MODIFY `id_hewan` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
