<?php 
session_start();
require 'koneksiHewan.php';


$link = "http://" . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"];
$hewan = query("SELECT * FROM data_hewan");

// if ( isset($SESSION["login"])) {
//   header("Location: index.php");
//   exit;
// }

//tombol cari yang sudah ditekan
if (isset($_POST["cari"])) {
  $hewan = cari($_POST["keyword"]);
  header("Location: cari.php");
  exit;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LETS FARM - KONTAK</title>
    <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css" />

  <link rel="stylesheet" type="text/css" href="style.css">
    <style type="text/css">
        /* tampilan haklaman kontak */
        /* kontak */
        .contact-list {
            margin-bottom: 100px;
            text-align: center;
            margin-top: 100px;
            /* background-color: whitesmoke; */
            /* background-color: aliceblue; */
        }

        .contact-list .contact {
            display: flex;
            justify-content: space-evenly;
            padding: 40px;
            flex-wrap: wrap;

        }

        .contact-list .contact1 {
            width: 240px;
            height: 240px;
            border: 1px solid #444;
            border-radius: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            margin-bottom: 50px;
            box-shadow: black;
        }

        .contact1 h3 {
            margin-bottom: 5px;
        }

        .contact1 img {
            width: 70px;
        }
        footer{
            background-color: #000;
            text-align: center;
            color: white;
            margin-top: 10px;
            padding: 20px;
            text-align: left;
        }
        
    </style>
</head>

<body>

    <!-- Navbar -->
  <header>
    <nav class="navbar fixed-top navbar-expand-md navbar-dark" style="background-color: #000000;">
      <div class="container">
        <a class="navbar-brand" href="index.php"><img src="img/logo.png" alt="" width="120"></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="tampilHewan.php">Beli Hewan</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="aboutus.php">About Us</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="contactus.php">Contact Us</a>
            </li>
          </ul>
          <form class="form-inline mt-2 mt-md-0" method="post">
            <input class="form-control mr-sm-2" type="text" placeholder="Cari" aria-label="Search" autocomplete="off" name="keyword">
            <button class="btn btn-outline-success my-2 mr-sm-2" type="submit" name="cari">Cari</button>            <?php
            if(!isset($_SESSION["login"])) :?>

              <a class="btn btn-sm btn-outline-secondary mr-2" href="loginform.php?continue=<?= $link ?>">Log In &nbsp;<i class="fa fa-sign-in"></i>
              </a>  
              <a class="btn btn-sm btn-outline-secondary" href="registrasi.php">Sign up &nbsp; <i class="fa fa-user-plus"></i>
              </a> 
              <?php elseif ($_SESSION["role"]=="User"):?>
              <!--script>
                alert('Selamat datang <?= $_SESSION["nama"];?>!');
                document.location.href = 'tampilHewan.php';
                </script> -->
                <div class="dropdown show">
                 <a class="btn btn-outline-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Halo, <?= $_SESSION["nama"]; ?>
                </a>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                  <a class="dropdown-item" href="logout.php" name="logout">Logout</a>
                  
                </div> 
              </div>  
              <?php else :?>
                <!-- <script>
                alert('Selamat datang <?= $_SESSION["nama"];?>!');
                document.location.href = 'tampilHewan.php';
                </script> -->
                <div class="dropdown show">
                 <a class="btn btn-outline-secondary dropdown-toggle btn-sm" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Halo, <?= $_SESSION["nama"]; ?>
                </a>
                <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                  <a class="dropdown-item" href="dashboard.php">Dashboard</a>
                  <a class="dropdown-item" href="logout.php" name="logout">Logout</a>
                </div>
              </div>
            <?php endif; ?>
          </form>
        </div>
      </div>
    </nav>
  </header>
  <!-- /Navbar -->


<div class="jumbotron">

<div class="container text-center" style="color: white;">
                <h1>Hubungi kami untuk keluhan berbagai
                    <br>masalah kapanpun dan dimanapun
                </h1>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                    <br> Dolor ea quam aspernatur minima sunt
                voluptates.</p>
            </div>    
</div>
    <section class="contact-list">
        <h1>Contact Us</h1>
        <div class="contact">
            <div class="contact1">
                <img src="img/plane.png" alt="">
                <h3>Email</h3>
                <p>letsfarm@LetsF.co.id</p>
            </div>
            <div class="contact1">
                <img src="img/phone.png" alt="">
                <h3>Phone Number</h3>
                <p>0822-2133-6645</p>
            </div>
            <div class="contact1">
                <img src="img/home.png" alt="">
                <h3>Address</h3>
                <p>Bandung, Indonesia</p>
            </div>
        </div>
    </section>

    <!-- Footer -->

  <footer class="footer mt-5 py-3 " style="background-color: #000000;">
    <div class="container">
      <span class="text-muted ">&copy;Let's Farm 2020</span>
      <p class="float-right"><a href="#">Back to top</a></p>
    </div>
  </footer>
  <!-- /Footer -->

  <!-- Optional JavaScript; choose one of the two! -->

  <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

    <!-- Option 2: jQuery, Popper.js, and Bootstrap JS
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
  -->
</body>

</html>