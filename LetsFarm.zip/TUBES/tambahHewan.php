<?php
session_start();
require 'koneksiHewan.php';

if (!isset($_SESSION["login"])) {
  header("Location: index.php");
  exit;
}

if ($_SESSION["role"] == "User") {
            header("Location: index.php");
            exit;
}

if (isset($_POST["submit"])) {

  //var_dump($_POST);die;
  //cekkk data berhasil
  if (tambah($_POST) > 0) {
    echo "
    <script>
    alert('data berhasil ditambahkan!');
    document.location.href = 'tampilHewan.php';
    </script>
    ";
  } else {

    echo "<script>
    alert('data gagal ditambahkan!');
    document.location.href = 'tampilHewan.php';
    </script>";
  }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Input Data Hewan</title>
</head>

<body>

  <a href="tampilHewan.php">Cek semua hewan</a>

  <form action="" method="POST" enctype="multipart/form-data">

    <ul>
      <li>
        <label for="nama_hewan">
          Nama Hewan
          <input type="text" name="nama_hewan" id="nama_hewan" required>
        </label>
      </li>
      <li>
        <label for="jenis_hewan">
          Jenis Hewan
          <input type="text" name="jenis_hewan" id="jenis_hewan" required>
        </label>
      </li>
      <li>
                <label>Jenis Kelamin</label>
                <?php   if (isset($error)) : ?>
                <p style="color: red; font-style: italic;">*Jenis kelamin jangan kosong! </p>
            <?php endif;   ?>
                <div class="form-check">
                    <input type="radio" name="jenis_kelamin" class="form-check-input" id="radio2"  value="Jantan" required>
                <label>Jantan</label>
                </div>

                <div class="form-check">
                    <input type="radio" name="jenis_kelamin" class="form-check-input" id="radio2" value="Betina">
                <label>Betina</label>
                </div>
      </li>
      <li>
        <label for="berat_hewan">
          Berat Hewan
          <input type="text" name="berat_hewan" id="berat_hewan" required>
        </label>
      </li>
      <li>
        <label for="umur_hewan">
          Umur Hewan
          <input type="text" name="umur_hewan" id="umur_hewan" required>
        </label>
      </li>
      <li>
        <label for="harga_hewan">
          Harga Hewan
          <input type="text" name="harga_hewan" id="harga_hewan" required>
        </label>
      </li>
      <li>
        <label for="jumlah_hewan">
          Jumlah
          <input type="text" name="jumlah_hewan" id="jumlah_hewan" required>
        </label>
      </li>
      <li>
        <label for="gambar">Gambar</label>
        <input type="file" name="gambar" id="gambar">
      </li>
      <li><button type="submit" name="submit">Submit</button></li>
    </ul>

  </form>

</body>

</html>