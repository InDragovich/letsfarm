<?php
session_start();
require 'koneksiHewan.php';

if ( !isset($_SESSION["login"])) {
  header("Location: index.php");
  exit;
}

if ($_SESSION["role"] == "User") {
            header("Location: index.php");
            exit;
}

//ambil data di url
$id = $_GET['id_hewan'];

//query data hewan berdasarkan id
$hewan = query("SELECT * FROM data_hewan WHERE id_hewan = $id")[0];
// var_dump($hewan);

//cek apakah tombol submit sudah ditekan atau belum
if (isset($_POST["submit"])) {

  //cek apakah data berhasil diubah atau tidak
  if (ubah($_POST) > 0) {
    echo "
		<script>
		alert('data berhasil diubah');
		document.location.href = 'tampilHewan.php'
		</script>
			";
  } else {
    echo "
		<script>
		alert('data gagal diubah');
		document.location.href = 'tampilHewan.php'
		</script>
			";
  }
}

?>

<!DOCTYPE html>
<html>
<head>
  <title>Update data Hewan</title>
</head>

<body>
  <h1>Update data Hewan</h1>
  <form action="" method="post" enctype="multipart/form-data" accept-charset="utf-8">
    <input type="hidden" name="id_hewan" value="<?= $hewan["id_hewan"]; ?>">
    <ul>
      <li>
        <label for="nama_hewan">Nama Hewan :</label>
        <input type="text" name="nama_hewan" id="nama_hewan" required value="<?= $hewan["nama_hewan"] ?>">
      </li>
      <li>
        <label for="jenis_hewan">Jenis Hewan :</label>
        <input type="text" name="jenis_hewan" id="jenis_hewan" value="<?= $hewan["jenis_hewan"] ?>">
      </li>
      <li>

        <label for="jenis_kelamin">Jenis Kelamin :</label>
        <input type="text" name="jenis_kelamin" id="jenis_kelamin" value="<?= $hewan["jenis_kelamin"] ?>">
      </li>
      <li>
        <label for="berat_hewan">Berat Hewan :</label>
        <input type="text" name="berat_hewan" id="berat_hewan" value="<?= $hewan["berat_hewan"] ?>">
      </li>
      <li>
        <label for="umur_hewan">Umur Hewan :</label>
        <input type="text" name="umur_hewan" id="umur_hewan" value="<?= $hewan["umur_hewan"] ?>">
      </li>
      <li>
        <label for="harga_hewan">Harga Hewan :</label>
        <input type="text" name="harga_hewan" id="harga_hewan" value="<?= $hewan["harga_hewan"] ?>">
      </li>
      <li>
        <label for="jumlah_hewan">Jumlah Hewan :</label>
        <input type="text" name="jumlah_hewan" id="jumlah_hewan" value="<?= $hewan["jumlah_hewan"] ?>">
      </li>
      <li>
        <label for="gambar">Gambar :</label><br>
        <img src="img/<?= $hewan['gambar']; ?> "width="50"><br> 
        <input type="file" name="gambar" id="gambar">
      </li>

    </ul>
    <button type="submit" name="submit">Update Data Hewan</button>
  </form>
</body>

</html>